<?php

class SanphamsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('sanphams')->truncate();

		$sanphams = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('sanphams')->insert($sanphams);
	}

}
