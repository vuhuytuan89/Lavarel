<?php

class Chung_loaisTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('chung_loais')->truncate();

		$chung_loais = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('chung_loais')->insert($chung_loais);
	}

}
