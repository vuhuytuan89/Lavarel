<?php

class TrangthaisTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('trangthais')->truncate();

		$trangthais = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('trangthais')->insert($trangthais);
	}

}
