<?php

class Nguoi_dungsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('nguoi_dungs')->truncate();

		$nguoi_dungs = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('nguoi_dungs')->insert($nguoi_dungs);
	}

}
