<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />






</head>

<body>
    <h3>Chào bạn!</h3>
    <p>Để hoàn tất việc lấy mật khẩu bạn cần nhấp vào đường link bên dưới</p>
    <a href='{{$link}}'>Hoàn tất lấy mật khẩu</a></br>
    <p>Mật khẩu tạm thời của bạn là: {{$mk}}</p>
    <p>Vui lòng thay đổi mật khẩu sau khi đăng nhập.</p>
</body>
</html>