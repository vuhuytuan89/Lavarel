   {{ Form::label('id_chungloai', 'Id_chungloai:') }}
            {{ Form::input('number', 'id_chungloai') }}