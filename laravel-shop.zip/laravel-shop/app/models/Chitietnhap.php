<?php

class Chitietnhap extends Eloquent{
    public $table="chitietnhap";
}
?>
