<?php

class Phieunhap extends Eloquent{
    public  $table="phieunhap";
}
?>
