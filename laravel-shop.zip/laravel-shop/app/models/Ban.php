<?php

class Ban extends Eloquent{
    public $table="ban";
}
?>
