<?php

class Donhang extends Eloquent{
    public $table="donhang";
}
?>
